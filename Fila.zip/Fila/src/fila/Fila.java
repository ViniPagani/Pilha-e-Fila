package fila;

public class Fila {
    private int capacidade;
    private int primeiro;
    private int ultimo;
    private int[] dados;

    // Construtor
    public Fila(int capacidade) {
        this.capacidade = capacidade;
        this.dados = new int[capacidade];
        this.primeiro = -1;
        this.ultimo = -1;
    }

    // Método para verificar se a fila está cheia
    public boolean cheia() {
        return (ultimo + 1) % capacidade == primeiro;
    }

    // Método para verificar se a fila está vazia
    public boolean vazia() {
        return primeiro == -1;
    }

    // Método para inserir um elemento na fila
    public void insere(int elemento) {
        if (cheia()) {
            System.out.println("Fila cheia. Nao e possivel inserir o elemento.");
        } else {
            if (vazia()) {
                primeiro = 0;
            }
            ultimo = (ultimo + 1) % capacidade;
            dados[ultimo] = elemento;
        }
    }

    // Método para remover um elemento da fila
    public int remove() {
        if (vazia()) {
            System.out.println("Fila vazia. Nao e possivel remover o elemento.");
            return -1;
        } else {
            int elementoRemovido = dados[primeiro];
            if (primeiro == ultimo) { // Fila ficou vazia após a remoção
                primeiro = -1;
                ultimo = -1;
            } else {
                primeiro = (primeiro + 1) % capacidade;
            }
            return elementoRemovido;
        }
    }

    // Método para imprimir todos os elementos da fila
    public void imprime() {
        if (vazia()) {
            System.out.println("Fila vazia.");
        } else {
            System.out.print("Elementos na fila: ");
            int i = primeiro;
            while (i != ultimo) {
                System.out.print(dados[i] + " ");
                i = (i + 1) % capacidade;
            }
            System.out.print(dados[ultimo] + "\n"); // Imprime o último elemento
        }
    }
}
