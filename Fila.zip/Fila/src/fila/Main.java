package fila;

public class Main {
    public static void main(String[] args) {
        Fila fila = new Fila(5);
        
        // Testando remoção em uma fila vazia
        fila.remove();
        
        // Inserindo elementos na fila
        fila.insere(10);
        fila.insere(20);
        fila.insere(30);
        fila.insere(40);
        fila.insere(50);
        
        // Tentando inserir em uma fila cheia
        fila.insere(60);
        
        // Imprimindo os elementos da fila
        fila.imprime();
        
        // Removendo elementos da fila
        fila.remove();
        fila.remove();
        
        // Imprimindo novamente após remoção
        fila.imprime();
    }
}
