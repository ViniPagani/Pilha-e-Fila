package pilha;

public class Pilha {
    private int capacidade;
    private int topo;
    private int[] dados;

    // Construtor
    public Pilha(int capacidade) {
        this.capacidade = capacidade;
        this.dados = new int[capacidade];
        this.topo = -1;
    }
    
    // Método para verificar se a pilha está cheia
    public boolean cheia() {
        return topo == capacidade - 1;
    }

    // Método para verificar se a pilha está vazia
    public boolean vazia() {
        return topo == -1;
    }
    
    // Método para inserir um elemento na pilha
    public void insere(int elemento) {
        if (cheia()) {
            System.out.println("Pilha cheia. Nao e possivel inserir o elemento.");
        } else {
            topo++;
            dados[topo] = elemento;
        }
    }

    // Método para remover um elemento da pilha
    public int remove() {
        if (vazia()) {
            System.out.println("Pilha vazia. Nao e possivel inserir o elemento.");
            return -1;
        } else {
            int elementoRemovido = dados[topo];
            topo--;
            return elementoRemovido;
        }
    }

    // Método para imprimir todos os elementos da pilha
    public void imprime() {
        if (vazia()) {
            System.out.println("Pilha vazia.");
        } else {
            System.out.print("Elementos na pilha: ");
            for (int i = 0; i <= topo; i++) {
                System.out.print(dados[i] + " ");
            }
            System.out.println();
        }
    }
}

