package pilha;

public class Main {
    public static void main(String[] args) {
        Pilha pilha = new Pilha(5);
        pilha.remove();
        pilha.insere(10);
        pilha.insere(20);
        pilha.insere(30);
        pilha.insere(30);
        pilha.insere(30);
        pilha.insere(30);
        pilha.imprime();
        pilha.remove();
        pilha.remove();
        pilha.imprime();
    }
}
